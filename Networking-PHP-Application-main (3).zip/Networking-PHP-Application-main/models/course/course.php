<?php

class Course
{
    public $id;
    public $name;
    public $desc;
    public $skills;
    public $hours;
    public $url;
}

?>