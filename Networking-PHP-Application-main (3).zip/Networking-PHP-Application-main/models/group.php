<?php

class Group
{
    public $id;
    public $name;
    public $desc;
}

?>