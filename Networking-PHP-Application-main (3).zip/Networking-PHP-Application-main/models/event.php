<?php

class Event
{
    public $id;
    public $title;
    public $desc;
    public $date;
}

?>