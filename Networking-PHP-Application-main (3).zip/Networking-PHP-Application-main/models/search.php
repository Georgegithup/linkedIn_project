<?php

class Search
{
    public $text;
}

?>