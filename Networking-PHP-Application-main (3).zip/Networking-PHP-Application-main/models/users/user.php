<?php 
class User 
{
    public $id;
    public $email;
    public $password;
    public $firstName;
    public $lastName;
    public $profileType;
    public $openTo;
    public $appliedJobs;
}
?>