<?php

class Endorse
{
    public $user1_id;
    public $user2_id;
    public $skill_id;
}

?>