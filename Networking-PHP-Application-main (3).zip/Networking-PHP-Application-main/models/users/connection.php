<?php

class Connection
{
    public $user1_id;
    public $user2_id;
    public $accepted;
}

?>