<?php

require_once "user.php";
class Premium extends User
{
    public $start_date;
    public $end_date;
}

?>