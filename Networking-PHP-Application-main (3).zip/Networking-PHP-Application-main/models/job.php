<?php

class Job
{
    public $id;
    public $title;
    public $desc;
    public $req;
    public $salary;
    public $company;
    public $location;
    public $creatorId;
}

?>