<?php

class Post
{
    public $id;
    public $user_id;
    public $desc;
    public $groupId;
}

?>