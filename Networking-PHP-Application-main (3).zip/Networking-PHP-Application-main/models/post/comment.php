<?php

class Comment
{
    public $id;
    public $user_id;
    public $post_id;
    public $comment;
}

?>