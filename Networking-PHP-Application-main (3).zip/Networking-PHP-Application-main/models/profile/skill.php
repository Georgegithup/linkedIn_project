<?php 

class skill
{
  public $id;
  public $name;
}


?>