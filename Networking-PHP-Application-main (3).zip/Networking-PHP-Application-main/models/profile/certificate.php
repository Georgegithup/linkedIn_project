<?php

class Certificate
{
    public $id;
    public $user_id;
    public $name;
    public $organization;
    public $issue_date;
    public $exp_date;
    public $cred_id;
    public $cred_url;
}
