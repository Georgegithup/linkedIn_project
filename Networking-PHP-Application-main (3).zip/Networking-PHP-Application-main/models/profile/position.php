<?php 

class Position 
{
  public $id;
  public $user_id;
  public $title;
  public $type;
  public $company;
  public $location;
  public $start_date;
  public $end_date;
  public $currently_working;
  public $industry;
}


?>