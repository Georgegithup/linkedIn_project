<?php 

class Website
{
  public $id;
  public $user_id;
  public $link;
  public $type;
}


?>