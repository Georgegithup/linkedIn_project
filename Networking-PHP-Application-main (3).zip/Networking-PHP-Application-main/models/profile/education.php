<?php 

class Education
{
  public $id;
  public $user_id;
  public $school;
  public $degree;
  public $field_of_study;
  public $start_date;
  public $end_date;
  public $grade;
}


?>