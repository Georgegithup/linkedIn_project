<?php 

class profile
{
  public $about;
  public $birthday;
  public $phone;
}


?>